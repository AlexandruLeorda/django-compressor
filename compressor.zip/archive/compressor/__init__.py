# following PEP 386
__version__ = "2.1"
